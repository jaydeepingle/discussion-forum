-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 26, 2013 at 05:31 PM
-- Server version: 5.5.24-log
-- PHP Version: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `forum_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` smallint(6) NOT NULL,
  `name` varchar(256) NOT NULL,
  `description` text NOT NULL,
  `position` smallint(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `position`) VALUES
(1, 'MS', 'This section deals with information about MS and studying abroad.', 1),
(2, 'MTech', 'This section deals with information about MTech and studying in India.', 2),
(3, 'Placements', 'This section deals with information on preparing for Campus Placements.', 3);

-- --------------------------------------------------------

--
-- Table structure for table `pm`
--

CREATE TABLE IF NOT EXISTS `pm` (
  `id` bigint(20) NOT NULL,
  `id2` int(11) NOT NULL,
  `title` varchar(256) NOT NULL,
  `user1` bigint(20) NOT NULL,
  `user2` bigint(20) NOT NULL,
  `message` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user1read` varchar(3) NOT NULL,
  `user2read` varchar(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pm`
--

INSERT INTO `pm` (`id`, `id2`, `title`, `user1`, `user2`, `message`, `timestamp`, `user1read`, `user2read`) VALUES
(1, 3, '', 1, 2, 'sdnsakdj', '2013-11-26 17:27:07', 'yes', 'yes'),
(1, 2, '', 1, 2, 'hhhh', '2013-11-26 17:23:05', 'yes', 'yes'),
(1, 1, 'Hi', 1, 2, 'hello', '2013-11-26 17:22:32', 'yes', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `topics`
--

CREATE TABLE IF NOT EXISTS `topics` (
  `parent` smallint(6) NOT NULL,
  `id` int(11) NOT NULL,
  `id2` int(11) NOT NULL,
  `title` varchar(256) NOT NULL,
  `message` longtext NOT NULL,
  `authorid` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `topics`
--

INSERT INTO `topics` (`parent`, `id`, `id2`, `title`, `message`, `authorid`, `timestamp`) VALUES
(1, 3, 1, 'Admission', 'This topic gives information about admissions in abroad universities.', 1, '2013-04-16 05:26:39'),
(2, 2, 1, 'GATE', 'This topic gives you information on GATE.', 1, '2013-04-15 05:44:21');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `signup_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `signup_date`) VALUES
(2, '111003021', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'atharva393@gmail.com', '2013-04-14 09:22:28'),
(3, '111003003', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'a@gmail.com', '2013-04-14 10:07:41'),
(4, '32423424', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'a@gmail.com', '2013-04-15 05:54:02'),
(5, '111003006', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'atharva393@gmail.com', '2013-04-15 06:36:36'),
(6, 'anurag...', 'a96a9493b7e75c97f07efe516bc0d2ee2d7aa291', 'anurag@gg.ac.in', '2013-04-15 12:43:45'),
(1, 'admin', '23d42f5f3f66498b2c8ff4c20b8c5ac826e47146', 'vaibhavvc1092@gmail.com', '2013-11-26 17:07:36');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
